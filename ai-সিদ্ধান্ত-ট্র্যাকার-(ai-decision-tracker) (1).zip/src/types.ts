export type Category = "আর্থিক" | "ক্যারিয়ার" | "সম্পর্ক" | "স্বাস্থ্য" | "ব্যবসা" | "শিক্ষা" | "অন্যান্য";
export type Emotion = "রাগ" | "ভয়" | "লোভ" | "উত্তেজনা" | "চাপ" | "দুঃখ" | "আনন্দ";
export type FinalDecision = "করেছি" | "করিনি" | "অপেক্ষমাণ";
export type Outcome = "ভালো হয়েছে" | "খারাপ হয়েছে" | "নিরপেক্ষ" | "এখনো জানি না";

export interface Decision {
  id: string;
  date: any; // Firestore Timestamp
  title: string;
  category: Category;
  emotions: Emotion[];
  intensity: number;
  scores: {
    chatgpt: number;
    claude: number;
    gemini: number;
    perplexity: number;
    ai5: number;
  };
  averageScore: number;
  passVotes: number;
  finalDecision: FinalDecision;
  outcome: Outcome;
  notes: string;
  attachments: string[];
  uid: string;
  createdAt: any; // Firestore Timestamp
}
