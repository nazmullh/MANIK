import * as React from 'react';
import { useState, useEffect, useMemo, Component, ReactNode } from 'react';
import { 
  Plus, 
  LayoutDashboard, 
  List, 
  Calendar, 
  Tag, 
  CheckCircle2, 
  AlertTriangle, 
  LogOut, 
  LogIn, 
  TrendingUp, 
  PieChart, 
  BarChart3,
  ChevronRight,
  ChevronDown,
  Trash2,
  Edit2,
  X,
  Save,
  Info,
  Clock,
  ThumbsUp,
  ThumbsDown,
  Minus,
  Upload,
  FileText,
  ExternalLink,
  Loader2,
  Copy,
  ArrowLeftRight,
  Check,
  Search
} from 'lucide-react';
import { 
  collection, 
  query, 
  where, 
  orderBy, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  serverTimestamp,
  Timestamp
} from 'firebase/firestore';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  signOut,
  User
} from 'firebase/auth';
import { 
  ref,
  uploadBytes,
  getDownloadURL,
  deleteObject
} from 'firebase/storage';
import { 
  AreaChart,
  Area,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart as RePieChart, 
  Pie, 
  Cell,
  BarChart,
  Bar,
  ReferenceLine
} from 'recharts';
import { format, startOfMonth, endOfMonth, isWithinInterval, parseISO } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

import { auth, db, storage, handleFirestoreError, OperationType } from './firebase';
import { Decision, Category, Emotion, FinalDecision, Outcome } from './types';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const CATEGORIES: Category[] = ["আর্থিক", "ক্যারিয়ার", "সম্পর্ক", "স্বাস্থ্য", "ব্যবসা", "শিক্ষা", "অন্যান্য"];
const EMOTIONS: Emotion[] = ["রাগ", "ভয়", "লোভ", "উত্তেজনা", "চাপ", "দুঃখ", "আনন্দ"];
const FINAL_DECISIONS: FinalDecision[] = ["করেছি", "করিনি", "অপেক্ষমাণ"];
const OUTCOMES: Outcome[] = ["ভালো হয়েছে", "খারাপ হয়েছে", "নিরপেক্ষ", "এখনো জানি না"];

// Error Boundary Component
interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: any;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = { hasError: false, error: null };

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      let errorMessage = "কিছু ভুল হয়েছে।";
      try {
        const errorInfo = JSON.parse(this.state.error.message);
        errorMessage = `Firestore ত্রুটি: ${errorInfo.operationType} এ ${errorInfo.path} পাথে সমস্যা হয়েছে।`;
      } catch (e) {
        errorMessage = this.state.error.message || errorMessage;
      }

      return (
        <div className="min-h-screen flex items-center justify-center bg-stone-50 p-6">
          <div className="max-w-md w-full bg-white p-8 rounded-3xl shadow-xl border border-red-100 text-center">
            <AlertTriangle className="text-red-500 w-12 h-12 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-stone-900 mb-2">দুঃখিত!</h2>
            <p className="text-stone-500 mb-6">{errorMessage}</p>
            <button 
              onClick={() => window.location.reload()}
              className="px-6 py-2 bg-stone-900 text-white rounded-xl font-medium hover:bg-stone-800 transition-all"
            >
              আবার চেষ্টা করুন
            </button>
          </div>
        </div>
      );
    }
    return (this as any).props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <MainApp />
    </ErrorBoundary>
  );
}

function MainApp() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'decisions' | 'add'>('dashboard');
  const [editingDecision, setEditingDecision] = useState<Decision | null>(null);
  const [viewMode, setViewMode] = useState<'all' | 'timeline' | 'category' | 'success' | 'high-risk'>('all');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isComparing, setIsComparing] = useState(false);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Test Connection
  useEffect(() => {
    const testConnection = async () => {
      try {
        const { getDocFromServer, doc } = await import('firebase/firestore');
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    };
    testConnection();
  }, []);

  // Decisions Listener
  useEffect(() => {
    if (!user) {
      setDecisions([]);
      return;
    }

    const q = query(
      collection(db, 'decisions'),
      where('uid', '==', user.uid),
      orderBy('date', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        ...doc.data(),
        id: doc.id,
        date: doc.data().date?.toDate() || new Date(),
        createdAt: doc.data().createdAt?.toDate() || new Date()
      })) as Decision[];
      setDecisions(docs);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'decisions');
    });

    return () => unsubscribe();
  }, [user]);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setActiveTab('dashboard');
    } catch (error) {
      console.error("Logout failed", error);
    }
  };

  const saveDecision = async (data: Partial<Decision>) => {
    if (!user) return;

    try {
      const avg = (
        (data.scores?.chatgpt || 0) + 
        (data.scores?.claude || 0) + 
        (data.scores?.gemini || 0) + 
        (data.scores?.perplexity || 0) + 
        (data.scores?.ai5 || 0)
      ) / 5;

      const payload = {
        ...data,
        averageScore: avg,
        uid: user.uid,
        updatedAt: serverTimestamp()
      };

      if (editingDecision) {
        await updateDoc(doc(db, 'decisions', editingDecision.id), payload);
        setEditingDecision(null);
      } else {
        await addDoc(collection(db, 'decisions'), {
          ...payload,
          createdAt: serverTimestamp()
        });
      }
      setActiveTab('decisions');
    } catch (error) {
      handleFirestoreError(error, editingDecision ? OperationType.UPDATE : OperationType.CREATE, 'decisions');
    }
  };

  const deleteDecision = async (id: string) => {
    if (!window.confirm("আপনি কি নিশ্চিত যে আপনি এই সিদ্ধান্তটি মুছে ফেলতে চান?")) return;
    try {
      await deleteDoc(doc(db, 'decisions', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `decisions/${id}`);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-stone-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-stone-800"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-stone-50 p-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-white p-8 rounded-3xl shadow-xl shadow-stone-200/50 text-center border border-stone-100"
        >
          <div className="w-20 h-20 bg-stone-900 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="text-white w-10 h-10" />
          </div>
          <h1 className="text-3xl font-bold text-stone-900 mb-2 font-serif">AI সিদ্ধান্ত ট্র্যাকার</h1>
          <p className="text-stone-500 mb-8">আপনার জীবনের গুরুত্বপূর্ণ সিদ্ধান্তগুলো AI এর সাহায্যে বিশ্লেষণ করুন এবং ট্র্যাক করুন।</p>
          <button 
            onClick={handleLogin}
            className="w-full py-4 bg-stone-900 text-white rounded-2xl font-semibold flex items-center justify-center gap-3 hover:bg-stone-800 transition-all active:scale-95"
          >
            <LogIn size={20} />
            গুগল দিয়ে লগইন করুন
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 font-sans pb-24 md:pb-0 md:pl-64">
      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex fixed left-0 top-0 bottom-0 w-64 bg-white border-r border-stone-200 flex-col p-6 z-30">
        <div className="flex items-center gap-3 mb-10 px-2">
          <div className="w-10 h-10 bg-stone-900 rounded-xl flex items-center justify-center">
            <CheckCircle2 className="text-white w-6 h-6" />
          </div>
          <span className="font-bold text-lg font-serif">AI ট্র্যাকার</span>
        </div>

        <nav className="flex-1 space-y-2">
          <SidebarLink 
            active={activeTab === 'dashboard'} 
            onClick={() => { setActiveTab('dashboard'); setEditingDecision(null); }}
            icon={<LayoutDashboard size={20} />}
            label="ড্যাশবোর্ড"
          />
          <SidebarLink 
            active={activeTab === 'decisions'} 
            onClick={() => { setActiveTab('decisions'); setEditingDecision(null); }}
            icon={<List size={20} />}
            label="সিদ্ধান্তসমূহ"
          />
          <SidebarLink 
            active={activeTab === 'add'} 
            onClick={() => { setActiveTab('add'); setEditingDecision(null); }}
            icon={<Plus size={20} />}
            label="নতুন সিদ্ধান্ত"
          />
        </nav>

        <div className="pt-6 border-t border-stone-100">
          <div className="flex items-center gap-3 mb-4 px-2">
            <img src={user.photoURL || ''} alt="" className="w-8 h-8 rounded-full" referrerPolicy="no-referrer" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.displayName}</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2 text-stone-500 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"
          >
            <LogOut size={18} />
            <span className="text-sm font-medium">লগআউট</span>
          </button>
        </div>
      </aside>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-stone-200 flex justify-around p-4 z-30">
        <MobileNavLink 
          active={activeTab === 'dashboard'} 
          onClick={() => { setActiveTab('dashboard'); setEditingDecision(null); }}
          icon={<LayoutDashboard size={24} />}
        />
        <MobileNavLink 
          active={activeTab === 'decisions'} 
          onClick={() => { setActiveTab('decisions'); setEditingDecision(null); }}
          icon={<List size={24} />}
        />
        <MobileNavLink 
          active={activeTab === 'add'} 
          onClick={() => { setActiveTab('add'); setEditingDecision(null); }}
          icon={<Plus size={24} />}
        />
        <button onClick={handleLogout} className="p-2 text-stone-400">
          <LogOut size={24} />
        </button>
      </nav>

      {/* Main Content */}
      <main className="p-4 md:p-8 max-w-6xl mx-auto">
        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <Dashboard key="dashboard" decisions={decisions} />
          )}
          {activeTab === 'decisions' && (
            <>
              <DecisionListView 
                key="decisions" 
                decisions={decisions} 
                onEdit={(d) => { setEditingDecision(d); setActiveTab('add'); }}
                onDelete={deleteDecision}
                viewMode={viewMode}
                setViewMode={setViewMode}
                selectedIds={selectedIds}
                onSelect={(id) => {
                  setSelectedIds(prev => 
                    prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
                  );
                }}
              />
              {selectedIds.length >= 2 && (
                <motion.div 
                  initial={{ y: 100 }}
                  animate={{ y: 0 }}
                  className="fixed bottom-24 md:bottom-8 left-1/2 -translate-x-1/2 z-40"
                >
                  <button 
                    onClick={() => setIsComparing(true)}
                    className="bg-stone-900 text-white px-8 py-4 rounded-2xl font-bold shadow-2xl flex items-center gap-3 hover:scale-105 transition-all"
                  >
                    <ArrowLeftRight size={20} />
                    {selectedIds.length}টি সিদ্ধান্ত তুলনা করুন
                  </button>
                </motion.div>
              )}
            </>
          )}
          {activeTab === 'add' && (
            <DecisionForm 
              key="add" 
              initialData={editingDecision} 
              onSave={saveDecision} 
              onCancel={() => { setActiveTab('decisions'); setEditingDecision(null); }} 
            />
          )}
        </AnimatePresence>
      </main>

      <AnimatePresence>
        {isComparing && (
          <ComparisonModal 
            decisions={decisions.filter(d => selectedIds.includes(d.id))}
            onClose={() => setIsComparing(false)}
            onClear={() => { setSelectedIds([]); setIsComparing(false); }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// --- Components ---

function SidebarLink({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium",
        active ? "bg-stone-900 text-white shadow-lg shadow-stone-900/20" : "text-stone-500 hover:bg-stone-100"
      )}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

function MobileNavLink({ active, onClick, icon }: { active: boolean, onClick: () => void, icon: React.ReactNode }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "p-3 rounded-2xl transition-all",
        active ? "bg-stone-900 text-white" : "text-stone-400"
      )}
    >
      {icon}
    </button>
  );
}

// --- Dashboard ---

function Dashboard({ decisions }: { decisions: Decision[], key?: string }) {
  const stats = useMemo(() => {
    const total = decisions.length;
    const passed = decisions.filter(d => d.passVotes >= 3).length;
    const passRate = total > 0 ? Math.round((passed / total) * 100) : 0;
    
    const emotionCounts: Record<string, number> = {};
    decisions.forEach(d => {
      d.emotions.forEach(e => {
        emotionCounts[e] = (emotionCounts[e] || 0) + 1;
      });
    });
    const topEmotion = Object.entries(emotionCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';

    const categoryData = CATEGORIES.map(cat => ({
      name: cat,
      value: decisions.filter(d => d.category === cat).length
    })).filter(c => c.value > 0);

    const trendData = decisions
      .slice()
      .sort((a, b) => a.date.getTime() - b.date.getTime())
      .map(d => ({
        date: format(d.date, 'MMM d'),
        score: Math.round(d.averageScore)
      }));

    const avgScore = trendData.length > 0 
      ? Math.round(trendData.reduce((acc, curr) => acc + curr.score, 0) / trendData.length) 
      : 0;

    return { total, passRate, topEmotion, categoryData, trendData, avgScore };
  }, [decisions]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-8"
    >
      <header>
        <h1 className="text-3xl font-bold font-serif mb-2">ড্যাশবোর্ড</h1>
        <p className="text-stone-500">আপনার সিদ্ধান্তের সংক্ষিপ্ত পরিসংখ্যান</p>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="মোট সিদ্ধান্ত" value={stats.total} icon={<List size={20} />} color="bg-blue-50 text-blue-600" />
        <StatCard label="PASS করা (%)" value={`${stats.passRate}%`} icon={<CheckCircle2 size={20} />} color="bg-green-50 text-green-600" />
        <StatCard label="শীর্ষ আবেগ" value={stats.topEmotion} icon={<TrendingUp size={20} />} color="bg-orange-50 text-orange-600" />
        <StatCard label="গড় স্কোর" value={stats.avgScore} icon={<BarChart3 size={20} />} color="bg-purple-50 text-purple-600" />
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Trend Chart */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
          <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
            <TrendingUp size={18} className="text-stone-400" />
            গড় AI স্কোর ট্রেন্ড
          </h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.trendData}>
                <defs>
                  <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#1c1917" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#1c1917" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f1f1" />
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#888' }} 
                  minTickGap={30}
                />
                <YAxis domain={[0, 100]} axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#888' }} />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                {stats.trendData.length > 0 && (
                  <ReferenceLine 
                    y={stats.avgScore} 
                    stroke="#78716c" 
                    strokeDasharray="3 3" 
                    label={{ value: 'গড়', position: 'right', fill: '#78716c', fontSize: 10, fontWeight: 'bold' }} 
                  />
                )}
                <Area 
                  type="monotone" 
                  dataKey="score" 
                  stroke="#1c1917" 
                  strokeWidth={3} 
                  fillOpacity={1} 
                  fill="url(#colorScore)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Breakdown */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
          <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
            <PieChart size={18} className="text-stone-400" />
            ক্যাটাগরি ব্রেকডাউন
          </h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <RePieChart>
                <Pie
                  data={stats.categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {stats.categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={['#1c1917', '#44403c', '#78716c', '#a8a29e', '#d6d3d1'][index % 5]} />
                  ))}
                </Pie>
                <Tooltip />
              </RePieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-4 justify-center mt-4">
            {stats.categoryData.map((entry, index) => (
              <div key={entry.name} className="flex items-center gap-2 text-xs font-medium text-stone-500">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: ['#1c1917', '#44403c', '#78716c', '#a8a29e', '#d6d3d1'][index % 5] }}></div>
                {entry.name}
              </div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function StatCard({ label, value, icon, color }: { label: string, value: string | number, icon: React.ReactNode, color: string }) {
  return (
    <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-sm">
      <div className={cn("w-10 h-10 rounded-2xl flex items-center justify-center mb-4", color)}>
        {icon}
      </div>
      <p className="text-stone-500 text-xs font-medium mb-1 uppercase tracking-wider">{label}</p>
      <p className="text-2xl font-bold">{value}</p>
    </div>
  );
}

// --- Decision Form ---

function DecisionForm({ initialData, onSave, onCancel }: { initialData: Decision | null, onSave: (data: Partial<Decision>) => Promise<void> | void, onCancel: () => void, key?: string }) {
  const [formData, setFormData] = useState<Partial<Decision>>(initialData || {
    date: new Date(),
    title: '',
    category: 'অন্যান্য',
    emotions: [],
    intensity: 5,
    scores: { chatgpt: 0, claude: 0, gemini: 0, perplexity: 0, ai5: 0 },
    passVotes: 0,
    finalDecision: 'অপেক্ষমাণ',
    outcome: 'এখনো জানি না',
    notes: '',
    attachments: []
  });
  const [uploading, setUploading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title) return alert("শিরোনাম দিন");
    onSave(formData);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !auth.currentUser) return;

    setUploading(true);
    try {
      const storageRef = ref(storage, `attachments/${auth.currentUser.uid}/${Date.now()}_${file.name}`);
      const snapshot = await uploadBytes(storageRef, file);
      const url = await getDownloadURL(snapshot.ref);
      
      setFormData(prev => ({
        ...prev,
        attachments: [...(prev.attachments || []), url]
      }));
    } catch (error) {
      console.error("Upload failed", error);
      alert("ফাইল আপলোড ব্যর্থ হয়েছে।");
    } finally {
      setUploading(false);
    }
  };

  const removeAttachment = async (url: string) => {
    setFormData(prev => ({
      ...prev,
      attachments: (prev.attachments || []).filter(a => a !== url)
    }));
    // Optional: Delete from storage as well
    try {
      const storageRef = ref(storage, url);
      await deleteObject(storageRef);
    } catch (error) {
      console.error("Delete failed", error);
    }
  };

  const toggleEmotion = (emotion: Emotion) => {
    const current = formData.emotions || [];
    if (current.includes(emotion)) {
      setFormData({ ...formData, emotions: current.filter(e => e !== emotion) });
    } else {
      setFormData({ ...formData, emotions: [...current, emotion] });
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-8"
    >
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-serif mb-2">{initialData ? 'সিদ্ধান্ত সম্পাদনা' : 'নতুন সিদ্ধান্ত'}</h1>
          <p className="text-stone-500">আপনার সিদ্ধান্তের বিস্তারিত তথ্য দিন</p>
        </div>
        <button onClick={onCancel} className="p-2 hover:bg-stone-200 rounded-full transition-all">
          <X size={24} />
        </button>
      </header>

      <form onSubmit={handleSubmit} className="space-y-8 pb-12">
        {/* Basic Info */}
        <section className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-stone-600">তারিখ</label>
              <input 
                type="date" 
                value={formData.date instanceof Date ? formData.date.toISOString().split('T')[0] : new Date().toISOString().split('T')[0]}
                onChange={(e) => setFormData({ ...formData, date: new Date(e.target.value) })}
                className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-stone-900 outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-stone-600">ক্যাটাগরি</label>
              <select 
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value as Category })}
                className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-stone-900 outline-none transition-all"
              >
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-semibold text-stone-600">সিদ্ধান্তের শিরোনাম</label>
            <input 
              type="text" 
              placeholder="যেমন: নতুন চাকরি পরিবর্তন করবো কি না?"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-stone-900 outline-none transition-all"
            />
          </div>
        </section>

        {/* Emotions */}
        <section className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-stone-600">আমার প্রাথমিক আবেগসমূহ</label>
            <div className="flex flex-wrap gap-2">
              {EMOTIONS.map(e => (
                <button
                  key={e}
                  type="button"
                  onClick={() => toggleEmotion(e)}
                  className={cn(
                    "px-4 py-2 rounded-full text-sm font-medium transition-all border",
                    formData.emotions?.includes(e) 
                      ? "bg-stone-900 text-white border-stone-900" 
                      : "bg-white text-stone-500 border-stone-200 hover:border-stone-400"
                  )}
                >
                  {e}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-sm font-semibold text-stone-600">আবেগ তীব্রতা</label>
              <span className="text-lg font-bold text-stone-900">{formData.intensity}/10</span>
            </div>
            <input 
              type="range" 
              min="1" 
              max="10" 
              value={formData.intensity}
              onChange={(e) => setFormData({ ...formData, intensity: parseInt(e.target.value) })}
              className="w-full h-2 bg-stone-100 rounded-lg appearance-none cursor-pointer accent-stone-900"
            />
          </div>
        </section>

        {/* AI Scores */}
        <section className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-6">
          <h3 className="text-lg font-bold flex items-center gap-2">
            <BarChart3 size={18} className="text-stone-400" />
            AI স্কোরসমূহ (0-100)
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <ScoreInput label="ChatGPT" value={formData.scores?.chatgpt || 0} onChange={(v) => setFormData({ ...formData, scores: { ...formData.scores!, chatgpt: v } })} />
            <ScoreInput label="Claude" value={formData.scores?.claude || 0} onChange={(v) => setFormData({ ...formData, scores: { ...formData.scores!, claude: v } })} />
            <ScoreInput label="Gemini" value={formData.scores?.gemini || 0} onChange={(v) => setFormData({ ...formData, scores: { ...formData.scores!, gemini: v } })} />
            <ScoreInput label="Perplexity" value={formData.scores?.perplexity || 0} onChange={(v) => setFormData({ ...formData, scores: { ...formData.scores!, perplexity: v } })} />
            <ScoreInput label="AI #5" value={formData.scores?.ai5 || 0} onChange={(v) => setFormData({ ...formData, scores: { ...formData.scores!, ai5: v } })} />
          </div>
          <div className="grid md:grid-cols-2 gap-6 pt-4 border-t border-stone-100">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-stone-600">PASS ভোট সংখ্যা (0-5)</label>
              <input 
                type="number" 
                min="0" 
                max="5" 
                value={formData.passVotes}
                onChange={(e) => setFormData({ ...formData, passVotes: parseInt(e.target.value) })}
                className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-stone-900 outline-none transition-all"
              />
            </div>
          </div>
        </section>

        {/* Final Decision & Outcome */}
        <section className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-stone-600">চূড়ান্ত সিদ্ধান্ত</label>
              <select 
                value={formData.finalDecision}
                onChange={(e) => setFormData({ ...formData, finalDecision: e.target.value as FinalDecision })}
                className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-stone-900 outline-none transition-all"
              >
                {FINAL_DECISIONS.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-stone-600">ফলাফল</label>
              <select 
                value={formData.outcome}
                onChange={(e) => setFormData({ ...formData, outcome: e.target.value as Outcome })}
                className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-stone-900 outline-none transition-all"
              >
                {OUTCOMES.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-semibold text-stone-600">শিক্ষা/নোট</label>
            <textarea 
              rows={4}
              placeholder="এই সিদ্ধান্ত থেকে আপনি কি শিখলেন বা কি নোট রাখতে চান?"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-stone-900 outline-none transition-all resize-none"
            />
          </div>

          {/* Attachments */}
          <div className="space-y-4">
            <label className="text-sm font-semibold text-stone-600">সংযুক্তি (AI responses এর screenshot)</label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {formData.attachments?.map((url, idx) => (
                <div key={idx} className="relative group aspect-square rounded-2xl overflow-hidden border border-stone-200 bg-stone-100">
                  <img src={url} alt="" className="w-full h-full object-cover" />
                  <button 
                    type="button"
                    onClick={() => removeAttachment(url)}
                    className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-all"
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
              <label className={cn(
                "aspect-square rounded-2xl border-2 border-dashed border-stone-200 flex flex-col items-center justify-center gap-2 cursor-pointer hover:border-stone-400 transition-all",
                uploading && "opacity-50 cursor-not-allowed"
              )}>
                {uploading ? (
                  <Loader2 className="animate-spin text-stone-400" size={24} />
                ) : (
                  <>
                    <Upload className="text-stone-400" size={24} />
                    <span className="text-[10px] font-bold text-stone-400 uppercase">আপলোড করুন</span>
                  </>
                )}
                <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} disabled={uploading} />
              </label>
            </div>
          </div>
        </section>

        <div className="flex gap-4">
          <button 
            type="submit"
            className="flex-1 py-4 bg-stone-900 text-white rounded-2xl font-semibold flex items-center justify-center gap-3 hover:bg-stone-800 transition-all active:scale-95"
          >
            <Save size={20} />
            সংরক্ষণ করুন
          </button>
          <button 
            type="button"
            onClick={onCancel}
            className="px-8 py-4 bg-stone-100 text-stone-600 rounded-2xl font-semibold hover:bg-stone-200 transition-all"
          >
            বাতিল
          </button>
        </div>
      </form>
    </motion.div>
  );
}

function ScoreInput({ label, value, onChange }: { label: string, value: number, onChange: (v: number) => void }) {
  return (
    <div className="space-y-2">
      <label className="text-xs font-bold text-stone-400 uppercase">{label}</label>
      <input 
        type="number" 
        min="0" 
        max="100" 
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value) || 0)}
        className="w-full p-2 bg-stone-50 border border-stone-200 rounded-lg focus:ring-2 focus:ring-stone-900 outline-none transition-all text-center font-mono"
      />
    </div>
  );
}

// --- Decision List View ---

function DecisionListView({ decisions, onEdit, onDelete, viewMode, setViewMode, selectedIds, onSelect }: { 
  decisions: Decision[], 
  onEdit: (d: Decision) => void, 
  onDelete: (id: string) => Promise<void> | void,
  viewMode: 'all' | 'timeline' | 'category' | 'success' | 'high-risk',
  setViewMode: (v: 'all' | 'timeline' | 'category' | 'success' | 'high-risk') => void,
  selectedIds: string[],
  onSelect: (id: string) => void,
  key?: string
}) {
  const [searchQuery, setSearchQuery] = useState('');
  
  const filteredDecisions = useMemo(() => {
    let result = decisions;

    // Apply View Mode Filters
    switch (viewMode) {
      case 'success':
        result = result.filter(d => d.finalDecision === 'করেছি');
        break;
      case 'high-risk':
        result = result.filter(d => 
          d.scores.chatgpt < 50 || 
          d.scores.claude < 50 || 
          d.scores.gemini < 50 || 
          d.scores.perplexity < 50 || 
          d.scores.ai5 < 50
        );
        break;
    }

    // Apply Search Query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(d => {
        const searchableText = [
          d.title,
          d.category,
          ...d.emotions,
          d.finalDecision,
          d.outcome,
          d.notes || '',
          ...(d.attachments || [])
        ].join(' ').toLowerCase();
        
        return searchableText.includes(query);
      });
    }

    return result;
  }, [decisions, viewMode, searchQuery]);

  const groupedDecisions = useMemo(() => {
    if (viewMode === 'timeline') {
      const groups: Record<string, Decision[]> = {};
      filteredDecisions.forEach(d => {
        const month = format(d.date, 'MMMM yyyy');
        if (!groups[month]) groups[month] = [];
        groups[month].push(d);
      });
      return Object.entries(groups);
    }
    if (viewMode === 'category') {
      const groups: Record<string, Decision[]> = {};
      filteredDecisions.forEach(d => {
        if (!groups[d.category]) groups[d.category] = [];
        groups[d.category].push(d);
      });
      return Object.entries(groups);
    }
    return null;
  }, [filteredDecisions, viewMode]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-8"
    >
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-serif mb-2">সিদ্ধান্তসমূহ</h1>
          <p className="text-stone-500">আপনার সংরক্ষিত সকল সিদ্ধান্তের তালিকা</p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
            <input 
              type="text"
              placeholder="খুঁজুন (টাইটেল, নোট, ইমোশন...)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 bg-white border border-stone-200 rounded-full text-sm focus:ring-2 focus:ring-stone-900 outline-none w-full md:w-64 transition-all"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <ViewTab active={viewMode === 'all'} onClick={() => setViewMode('all')} label="সব" icon={<List size={16} />} />
            <ViewTab active={viewMode === 'timeline'} onClick={() => setViewMode('timeline')} label="টাইমলাইন" icon={<Calendar size={16} />} />
            <ViewTab active={viewMode === 'category'} onClick={() => setViewMode('category')} label="ক্যাটাগরি" icon={<Tag size={16} />} />
            <ViewTab active={viewMode === 'success'} onClick={() => setViewMode('success')} label="সফলতা" icon={<CheckCircle2 size={16} />} />
            <ViewTab active={viewMode === 'high-risk'} onClick={() => setViewMode('high-risk')} label="হাই রিস্ক" icon={<AlertTriangle size={16} />} />
          </div>
        </div>
      </header>

      <div className="space-y-12">
        {groupedDecisions ? (
          groupedDecisions.map(([group, items]) => (
            <section key={group} className="space-y-4">
              <h2 className="text-xl font-bold font-serif flex items-center gap-3 text-stone-400">
                <span className="w-8 h-px bg-stone-200"></span>
                {group}
                <span className="text-sm font-normal bg-stone-100 px-2 py-0.5 rounded-full text-stone-500">{items.length}</span>
              </h2>
              <div className="grid gap-4">
                {items.map(d => (
                  <DecisionCard 
                    key={d.id} 
                    decision={d} 
                    onEdit={() => onEdit(d)} 
                    onDelete={() => onDelete(d.id)} 
                    isSelected={selectedIds.includes(d.id)}
                    onSelect={() => onSelect(d.id)}
                  />
                ))}
              </div>
            </section>
          ))
        ) : (
          <div className="grid gap-4">
            {filteredDecisions.length > 0 ? (
              filteredDecisions.map(d => (
                <DecisionCard 
                  key={d.id} 
                  decision={d} 
                  onEdit={() => onEdit(d)} 
                  onDelete={() => onDelete(d.id)} 
                  isSelected={selectedIds.includes(d.id)}
                  onSelect={() => onSelect(d.id)}
                />
              ))
            ) : (
              <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-stone-300">
                <div className="w-16 h-16 bg-stone-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Info className="text-stone-300" />
                </div>
                <p className="text-stone-400">কোনো সিদ্ধান্ত খুঁজে পাওয়া যায়নি</p>
              </div>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}

function ViewTab({ active, onClick, label, icon }: { active: boolean, onClick: () => void, label: string, icon: React.ReactNode }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all",
        active ? "bg-stone-900 text-white shadow-md shadow-stone-900/20" : "bg-white text-stone-500 border border-stone-200 hover:border-stone-400"
      )}
    >
      {icon}
      {label}
    </button>
  );
}

function DecisionCard({ decision, onEdit, onDelete, isSelected, onSelect }: { 
  decision: Decision, 
  onEdit: () => void, 
  onDelete: () => void, 
  isSelected: boolean,
  onSelect: () => void,
  key?: string 
}) {
  const [isExpanded, setIsExpanded] = useState(false);

  const getOutcomeIcon = (outcome: Outcome) => {
    switch (outcome) {
      case 'ভালো হয়েছে': return <ThumbsUp size={16} className="text-green-600" />;
      case 'খারাপ হয়েছে': return <ThumbsDown size={16} className="text-red-600" />;
      case 'নিরপেক্ষ': return <Minus size={16} className="text-stone-600" />;
      default: return <Clock size={16} className="text-stone-400" />;
    }
  };

  const getDecisionBadge = (d: FinalDecision) => {
    switch (d) {
      case 'করেছি': return "bg-green-100 text-green-700";
      case 'করিনি': return "bg-red-100 text-red-700";
      default: return "bg-stone-100 text-stone-700";
    }
  };

  return (
    <div className={cn(
      "bg-white rounded-3xl border transition-all hover:shadow-md overflow-hidden relative",
      isSelected ? "border-stone-900 ring-2 ring-stone-900/10" : "border-stone-200 shadow-sm"
    )}>
      <div className="p-5 flex items-start justify-between gap-4">
        <div className="flex items-start gap-4 flex-1">
          <button 
            onClick={onSelect}
            className={cn(
              "mt-1 w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all shrink-0",
              isSelected ? "bg-stone-900 border-stone-900 text-white" : "border-stone-200 hover:border-stone-400"
            )}
          >
            {isSelected && <Check size={14} />}
          </button>
          
          <div className="flex-1 space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold text-stone-400 uppercase tracking-tighter">{format(decision.date, 'MMM d, yyyy')}</span>
              <span className="w-1 h-1 bg-stone-300 rounded-full"></span>
              <span className="text-xs font-bold text-stone-900 bg-stone-100 px-2 py-0.5 rounded-md">{decision.category}</span>
              <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded-md uppercase", getDecisionBadge(decision.finalDecision))}>
                {decision.finalDecision}
              </span>
            </div>
            <h3 className="text-lg font-bold font-serif leading-tight">{decision.title}</h3>
            <div className="flex flex-wrap gap-1">
              {decision.emotions.map(e => (
                <span key={e} className="text-[10px] bg-stone-50 text-stone-500 px-2 py-0.5 rounded-full border border-stone-100">{e}</span>
              ))}
            </div>
          </div>
        </div>

        <div className="flex flex-col items-end gap-2">
          <div className="text-right">
            <div className="text-2xl font-black text-stone-900">{Math.round(decision.averageScore)}</div>
            <div className="text-[10px] font-bold text-stone-400 uppercase">Avg Score</div>
          </div>
          <div className="flex gap-1">
            <button onClick={onEdit} className="p-2 hover:bg-stone-100 rounded-lg text-stone-400 hover:text-stone-900 transition-all">
              <Edit2 size={16} />
            </button>
            <button onClick={onDelete} className="p-2 hover:bg-red-50 rounded-lg text-stone-400 hover:text-red-600 transition-all">
              <Trash2 size={16} />
            </button>
            <button onClick={() => setIsExpanded(!isExpanded)} className="p-2 hover:bg-stone-100 rounded-lg text-stone-400 transition-all">
              <ChevronDown size={16} className={cn("transition-transform", isExpanded && "rotate-180")} />
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-stone-100 bg-stone-50/50 overflow-hidden"
          >
            <div className="p-5 space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <ScoreDisplay label="ChatGPT" value={decision.scores.chatgpt} />
                <ScoreDisplay label="Claude" value={decision.scores.claude} />
                <ScoreDisplay label="Gemini" value={decision.scores.gemini} />
                <ScoreDisplay label="Perplexity" value={decision.scores.perplexity} />
                <ScoreDisplay label="AI #5" value={decision.scores.ai5} />
              </div>

              <div className="grid md:grid-cols-3 gap-6">
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-stone-400 uppercase">PASS ভোট</p>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map(i => (
                      <div key={i} className={cn("w-4 h-1.5 rounded-full", i <= decision.passVotes ? "bg-green-500" : "bg-stone-200")}></div>
                    ))}
                  </div>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-stone-400 uppercase">আবেগ তীব্রতা</p>
                  <div className="w-full h-1.5 bg-stone-200 rounded-full overflow-hidden">
                    <div className="h-full bg-orange-500" style={{ width: `${decision.intensity * 10}%` }}></div>
                  </div>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-stone-400 uppercase">ফলাফল</p>
                  <div className="flex items-center gap-2 text-sm font-medium">
                    {getOutcomeIcon(decision.outcome)}
                    {decision.outcome}
                  </div>
                </div>
              </div>

              {decision.notes && (
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-stone-400 uppercase">শিক্ষা/নোট</p>
                  <p className="text-sm text-stone-600 leading-relaxed italic">"{decision.notes}"</p>
                </div>
              )}

              {decision.attachments && decision.attachments.length > 0 && (
                <div className="space-y-2">
                  <p className="text-[10px] font-bold text-stone-400 uppercase">সংযুক্তি</p>
                  <div className="flex flex-wrap gap-3">
                    {decision.attachments.map((url, idx) => (
                      <a 
                        key={idx} 
                        href={url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="relative w-20 h-20 rounded-xl overflow-hidden border border-stone-200 hover:border-stone-900 transition-all group"
                      >
                        <img src={url} alt="" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-stone-900/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-all">
                          <ExternalLink size={16} className="text-white" />
                        </div>
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ScoreDisplay({ label, value }: { label: string, value: number }) {
  return (
    <div className="text-center p-2 bg-white rounded-xl border border-stone-100 shadow-sm">
      <div className="text-[8px] font-bold text-stone-400 uppercase mb-1">{label}</div>
      <div className={cn("text-sm font-black", value >= 80 ? "text-green-600" : value >= 50 ? "text-stone-900" : "text-red-600")}>
        {value}
      </div>
    </div>
  );
}

// --- Comparison Modal ---

function ComparisonModal({ decisions, onClose, onClear }: { decisions: Decision[], onClose: () => void, onClear: () => void }) {
  const sortedDecisions = useMemo(() => {
    return [...decisions].sort((a, b) => a.date.getTime() - b.date.getTime());
  }, [decisions]);

  const trendData = useMemo(() => {
    return sortedDecisions.map(d => ({
      date: format(d.date, 'MMM d'),
      score: Math.round(d.averageScore),
      title: d.title
    }));
  }, [sortedDecisions]);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-stone-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 md:p-8"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-white w-full max-w-6xl max-h-full rounded-[40px] shadow-2xl overflow-hidden flex flex-col"
      >
        <header className="p-6 md:p-8 border-b border-stone-100 flex items-center justify-between bg-stone-50/50">
          <div>
            <h2 className="text-2xl font-bold font-serif">সিদ্ধান্ত তুলনা</h2>
            <p className="text-stone-500 text-sm">{decisions.length}টি সিদ্ধান্তের পাশাপাশি তুলনা</p>
          </div>
          <div className="flex gap-3">
            <button onClick={onClear} className="text-stone-400 hover:text-stone-900 text-sm font-bold uppercase tracking-widest">সব মুছুন</button>
            <button onClick={onClose} className="p-2 hover:bg-stone-200 rounded-full transition-all">
              <X size={24} />
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-auto p-6 md:p-8 space-y-8">
          {/* Trend Chart for Selected Decisions */}
          <div className="bg-stone-50 p-6 rounded-3xl border border-stone-100">
            <h3 className="text-sm font-bold text-stone-400 uppercase tracking-widest mb-6 flex items-center gap-2">
              <TrendingUp size={16} />
              নির্বাচিত সিদ্ধান্তের স্কোর ট্রেন্ড
            </h3>
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendData}>
                  <defs>
                    <linearGradient id="colorScoreComp" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#1c1917" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#1c1917" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e5e5" />
                  <XAxis 
                    dataKey="date" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 10, fill: '#888' }} 
                  />
                  <YAxis domain={[0, 100]} axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#888' }} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    labelStyle={{ fontWeight: 'bold', marginBottom: '4px' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="score" 
                    stroke="#1c1917" 
                    strokeWidth={3} 
                    fillOpacity={1} 
                    fill="url(#colorScoreComp)" 
                    dot={{ r: 4, fill: '#1c1917', strokeWidth: 2, stroke: '#fff' }}
                    activeDot={{ r: 6 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="min-w-[800px]">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="p-4 text-left bg-stone-50/50 rounded-tl-2xl border-b border-stone-100 w-48"></th>
                  {decisions.map(d => (
                    <th key={d.id} className="p-4 text-left bg-stone-50/50 border-b border-stone-100 min-w-[250px]">
                      <div className="text-xs font-bold text-stone-400 uppercase mb-1">{format(d.date, 'MMM d, yyyy')}</div>
                      <div className="text-lg font-bold font-serif leading-tight">{d.title}</div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                <CompareRow label="ক্যাটাগরি" values={decisions.map(d => d.category)} />
                <CompareRow label="গড় AI স্কোর" values={decisions.map(d => Math.round(d.averageScore))} isScore />
                <CompareRow label="ChatGPT" values={decisions.map(d => d.scores.chatgpt)} isScore />
                <CompareRow label="Claude" values={decisions.map(d => d.scores.claude)} isScore />
                <CompareRow label="Gemini" values={decisions.map(d => d.scores.gemini)} isScore />
                <CompareRow label="Perplexity" values={decisions.map(d => d.scores.perplexity)} isScore />
                <CompareRow label="AI #5" values={decisions.map(d => d.scores.ai5)} isScore />
                <CompareRow label="PASS ভোট" values={decisions.map(d => `${d.passVotes}/5`)} />
                <CompareRow label="আবেগসমূহ" values={decisions.map(d => d.emotions.join(', '))} />
                <CompareRow label="আবেগ তীব্রতা" values={decisions.map(d => `${d.intensity}/10`)} />
                <CompareRow label="চূড়ান্ত সিদ্ধান্ত" values={decisions.map(d => d.finalDecision)} />
                <CompareRow label="ফলাফল" values={decisions.map(d => d.outcome)} />
                <CompareRow label="শিক্ষা/নোট" values={decisions.map(d => d.notes || 'N/A')} isLongText />
              </tbody>
            </table>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

function CompareRow({ label, values, isScore, isLongText }: { label: string, values: any[], isScore?: boolean, isLongText?: boolean }) {
  const isDifferent = new Set(values).size > 1;

  return (
    <tr className={cn(isDifferent && "bg-stone-50/30")}>
      <td className="p-4 font-bold text-stone-400 text-xs uppercase tracking-wider border-r border-stone-100">{label}</td>
      {values.map((v, i) => (
        <td key={i} className={cn("p-4 text-sm", isLongText ? "italic text-stone-500" : "font-medium")}>
          {isScore ? (
            <span className={cn(
              "px-3 py-1 rounded-full font-black",
              v >= 80 ? "bg-green-100 text-green-700" : v >= 50 ? "bg-stone-100 text-stone-900" : "bg-red-100 text-red-700"
            )}>
              {v}
            </span>
          ) : (
            v
          )}
        </td>
      ))}
    </tr>
  );
}
